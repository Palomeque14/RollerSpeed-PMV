INSERT INTO user (username, password, role)
VALUES ('instructor1', '$2a$12$WVN0ka3FmXnxtDYd8gwEOOqGfqdWHKNoclBTvXIEUXMuKRbWfDBDq', 'USER');
