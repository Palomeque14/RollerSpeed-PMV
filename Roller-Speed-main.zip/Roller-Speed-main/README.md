## Base de Datos

El archivo SQL con la estructura de la base de datos se encuentra en `/database/roller_speed_db.sql`.

Para usarlo:
1. Abrir MySQL Workbench u otro cliente.
2. Ejecutar el archivo para crear la base de datos y todas sus tablas.
