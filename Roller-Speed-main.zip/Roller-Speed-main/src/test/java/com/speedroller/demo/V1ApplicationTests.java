package com.speedroller.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class V1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
