package com.speedroller.demo.Model;

public enum Role {
    USER,
    ADMIN
}